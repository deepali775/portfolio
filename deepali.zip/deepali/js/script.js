"use strict";
const year = new Date().getFullYear();
document.querySelector(".year").textContent = year;
